-- ============================================================
-- CAFE CUSTOMER ANALYSIS
-- REVENUE AND PAYMENT ANALYSIS
-- ============================================================

USE cafe_customer_analysis;

-- Q33. Total revenue
SELECT
    ROUND(SUM(final_amount), 2) AS total_revenue
FROM Orders
WHERE order_status <> 'Cancelled';

-- Q34. Monthly revenue
SELECT
    DATE_FORMAT(order_date, '%Y-%m') AS revenue_month,
    ROUND(SUM(final_amount), 2) AS monthly_revenue
FROM Orders
WHERE order_status <> 'Cancelled'
GROUP BY DATE_FORMAT(order_date, '%Y-%m')
ORDER BY revenue_month;

-- Q35. Revenue by payment method
SELECT
    payment_method,
    COUNT(*) AS payment_count,
    ROUND(
        SUM(CASE WHEN payment_status = 'Paid' THEN amount ELSE 0 END),
        2
    ) AS paid_revenue
FROM Payments
GROUP BY payment_method
ORDER BY paid_revenue DESC;

-- Q36. Payment status analysis
SELECT
    payment_status,
    COUNT(*) AS payment_count,
    ROUND(SUM(amount), 2) AS payment_amount
FROM Payments
GROUP BY payment_status
ORDER BY payment_amount DESC;

-- Q37. Top revenue-generating customers
SELECT
    c.customer_id,
    c.name,
    ROUND(SUM(o.final_amount), 2) AS revenue
FROM Customers c
JOIN Orders o
    ON c.customer_id = o.customer_id
WHERE o.order_status <> 'Cancelled'
GROUP BY c.customer_id, c.name
ORDER BY revenue DESC
LIMIT 10;

-- Q38. Revenue percentage by category
WITH category_revenue AS (
    SELECT
        category_name,
        revenue
    FROM vw_CategoryRevenue
)
SELECT
    category_name,
    revenue,
    ROUND(
        100 * revenue /
        NULLIF((SELECT SUM(revenue) FROM category_revenue), 0),
        2
    ) AS revenue_percentage
FROM category_revenue
ORDER BY revenue_percentage DESC;

-- Q39. Month-over-month revenue growth
WITH monthly_revenue AS (
    SELECT
        DATE_FORMAT(order_date, '%Y-%m') AS revenue_month,
        SUM(final_amount) AS revenue
    FROM Orders
    WHERE order_status <> 'Cancelled'
    GROUP BY DATE_FORMAT(order_date, '%Y-%m')
),
revenue_with_previous AS (
    SELECT
        revenue_month,
        revenue,
        LAG(revenue) OVER (
            ORDER BY revenue_month
        ) AS previous_month_revenue
    FROM monthly_revenue
)
SELECT
    revenue_month,
    revenue,
    previous_month_revenue,
    ROUND(
        100 * (revenue - previous_month_revenue) /
        NULLIF(previous_month_revenue, 0),
        2
    ) AS growth_percentage
FROM revenue_with_previous
ORDER BY revenue_month;

-- Q40. Cumulative revenue
WITH monthly_revenue AS (
    SELECT
        DATE_FORMAT(order_date, '%Y-%m') AS revenue_month,
        SUM(final_amount) AS revenue
    FROM Orders
    WHERE order_status <> 'Cancelled'
    GROUP BY DATE_FORMAT(order_date, '%Y-%m')
)
SELECT
    revenue_month,
    revenue,
    SUM(revenue) OVER (
        ORDER BY revenue_month
    ) AS cumulative_revenue
FROM monthly_revenue
ORDER BY revenue_month;

-- Q41. Payment amount vs order final amount
SELECT
    o.order_id,
    o.final_amount AS order_final_amount,
    p.amount AS payment_amount,
    p.payment_status,
    CASE
        WHEN p.payment_status = 'Paid'
             AND p.amount = o.final_amount THEN 'Matched'
        WHEN p.payment_status = 'Paid'
             AND p.amount <> o.final_amount THEN 'Mismatch'
        WHEN p.payment_status IN ('Pending','Failed') THEN 'Unsettled'
        ELSE 'Review'
    END AS payment_check
FROM Orders o
LEFT JOIN Payments p
    ON o.order_id = p.order_id
ORDER BY o.order_id;

-- Q42. Revenue by city
SELECT
    c.city,
    COUNT(DISTINCT o.order_id) AS order_count,
    ROUND(SUM(o.final_amount), 2) AS revenue
FROM Customers c
JOIN Orders o
    ON c.customer_id = o.customer_id
WHERE o.order_status <> 'Cancelled'
GROUP BY c.city
ORDER BY revenue DESC;
