-- ============================================================
-- CAFE CUSTOMER ANALYSIS
-- PRODUCT ANALYSIS
-- ============================================================

USE cafe_customer_analysis;

-- Q13. Best-selling products by quantity
SELECT
    product_id,
    product_name,
    quantity_sold
FROM vw_ProductSalesSummary
ORDER BY quantity_sold DESC, product_name
LIMIT 10;

-- Q14. Highest-revenue products
SELECT
    product_id,
    product_name,
    revenue
FROM vw_ProductSalesSummary
ORDER BY revenue DESC
LIMIT 10;

-- Q15. Products with no orders
SELECT
    product_id,
    product_name,
    category_name
FROM vw_ProductSalesSummary
WHERE quantity_sold = 0;

-- Q16. Low-performing products
SELECT
    product_id,
    product_name,
    category_name,
    quantity_sold,
    revenue
FROM vw_ProductPerformance
WHERE sales_segment IN ('No Sales', 'Low Sales')
ORDER BY quantity_sold, revenue;

-- Q17. Revenue by category
SELECT
    category_id,
    category_name,
    quantity_sold,
    revenue
FROM vw_CategoryRevenue
ORDER BY revenue DESC;

-- Q18. Average selling price by category
SELECT
    c.category_id,
    c.category_name,
    ROUND(AVG(p.price), 2) AS average_product_price
FROM Categories c
JOIN Products p
    ON c.category_id = p.category_id
GROUP BY c.category_id, c.category_name
ORDER BY average_product_price DESC;

-- Q19. Product contribution to total revenue
SELECT
    product_id,
    product_name,
    revenue,
    ROUND(
        100 * revenue / NULLIF(
            (SELECT SUM(revenue)
             FROM vw_ProductSalesSummary),
            0
        ), 2
    ) AS revenue_percentage
FROM vw_ProductSalesSummary
ORDER BY revenue_percentage DESC;

-- Q20. Rank products by revenue
SELECT
    product_id,
    product_name,
    category_name,
    revenue,
    DENSE_RANK() OVER (
        ORDER BY revenue DESC
    ) AS revenue_rank
FROM vw_ProductSalesSummary
ORDER BY revenue_rank;

-- Q21. Top 3 products within each category
WITH ranked_products AS (
    SELECT
        product_id,
        product_name,
        category_name,
        revenue,
        DENSE_RANK() OVER (
            PARTITION BY category_name
            ORDER BY revenue DESC
        ) AS category_rank
    FROM vw_ProductSalesSummary
)
SELECT *
FROM ranked_products
WHERE category_rank <= 3
ORDER BY category_name, category_rank;

-- Q22. Estimated product profit
SELECT
    p.product_id,
    p.product_name,
    p.price AS selling_price,
    -- This project does not store product cost_price in the ER schema.
    -- Therefore this query reports sales revenue, not profit.
    ps.quantity_sold,
    ps.revenue
FROM Products p
JOIN vw_ProductSalesSummary ps
    ON p.product_id = ps.product_id
ORDER BY ps.revenue DESC;
