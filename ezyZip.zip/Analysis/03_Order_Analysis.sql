-- ============================================================
-- CAFE CUSTOMER ANALYSIS
-- ORDER ANALYSIS
-- ============================================================

USE cafe_customer_analysis;

-- Q23. Total orders
SELECT COUNT(*) AS total_orders
FROM Orders;

-- Q24. Average Order Value
SELECT
    ROUND(AVG(final_amount), 2) AS average_order_value
FROM Orders
WHERE order_status <> 'Cancelled';

-- Q25. Daily order volume
SELECT
    DATE(order_date) AS order_day,
    COUNT(*) AS order_count
FROM Orders
GROUP BY DATE(order_date)
ORDER BY order_day;

-- Q26. Monthly order trends
SELECT
    DATE_FORMAT(order_date, '%Y-%m') AS order_month,
    COUNT(*) AS order_count,
    SUM(final_amount) AS revenue
FROM Orders
WHERE order_status <> 'Cancelled'
GROUP BY DATE_FORMAT(order_date, '%Y-%m')
ORDER BY order_month;

-- Q27. Busy ordering hours
SELECT
    HOUR(order_date) AS order_hour,
    COUNT(*) AS order_count
FROM Orders
GROUP BY HOUR(order_date)
ORDER BY order_count DESC;

-- Q28. Order status distribution
SELECT
    order_status,
    COUNT(*) AS order_count,
    ROUND(
        100 * COUNT(*) / (SELECT COUNT(*) FROM Orders),
        2
    ) AS percentage_of_orders
FROM Orders
GROUP BY order_status
ORDER BY order_count DESC;

-- Q29. Orders above the average order value
SELECT
    order_id,
    customer_id,
    order_date,
    final_amount
FROM Orders
WHERE order_status <> 'Cancelled'
  AND final_amount > (
      SELECT AVG(final_amount)
      FROM Orders
      WHERE order_status <> 'Cancelled'
  )
ORDER BY final_amount DESC;

-- Q30. Orders with multiple items
SELECT
    o.order_id,
    c.name AS customer_name,
    COUNT(oi.order_item_id) AS item_lines,
    SUM(oi.quantity) AS total_quantity,
    o.final_amount
FROM Orders o
JOIN Customers c
    ON o.customer_id = c.customer_id
JOIN OrderItems oi
    ON o.order_id = oi.order_id
WHERE o.order_status <> 'Cancelled'
GROUP BY
    o.order_id,
    c.name,
    o.final_amount
HAVING COUNT(oi.order_item_id) > 1
ORDER BY item_lines DESC;

-- Q31. Orders handled by each employee
SELECT
    e.employee_id,
    e.name AS employee_name,
    COUNT(o.order_id) AS orders_handled,
    COALESCE(SUM(
        CASE WHEN o.order_status <> 'Cancelled'
             THEN o.final_amount ELSE 0 END
    ), 0) AS handled_revenue
FROM Employees e
LEFT JOIN Orders o
    ON e.employee_id = o.employee_id
GROUP BY e.employee_id, e.name
ORDER BY orders_handled DESC;

-- Q32. Average order value by employee
SELECT
    e.employee_id,
    e.name AS employee_name,
    ROUND(
        AVG(
            CASE WHEN o.order_status <> 'Cancelled'
                 THEN o.final_amount END
        ), 2
    ) AS average_order_value
FROM Employees e
LEFT JOIN Orders o
    ON e.employee_id = o.employee_id
GROUP BY e.employee_id, e.name
ORDER BY average_order_value DESC;
