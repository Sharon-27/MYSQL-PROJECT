-- ============================================================
-- CAFE CUSTOMER ANALYSIS
-- ADVANCED ANALYSIS
-- ============================================================

USE cafe_customer_analysis;

-- Q43. First order for each customer
WITH ranked_orders AS (
    SELECT
        o.customer_id,
        o.order_id,
        o.order_date,
        o.final_amount,
        ROW_NUMBER() OVER (
            PARTITION BY o.customer_id
            ORDER BY o.order_date
        ) AS rn
    FROM Orders o
    WHERE o.order_status <> 'Cancelled'
)
SELECT
    c.customer_id,
    c.name,
    r.order_id AS first_order_id,
    r.order_date AS first_order_date,
    r.final_amount AS first_order_value
FROM Customers c
JOIN ranked_orders r
    ON c.customer_id = r.customer_id
WHERE r.rn = 1
ORDER BY first_order_date;

-- Q44. Second order for each customer where available
WITH ranked_orders AS (
    SELECT
        o.customer_id,
        o.order_id,
        o.order_date,
        ROW_NUMBER() OVER (
            PARTITION BY o.customer_id
            ORDER BY o.order_date
        ) AS rn
    FROM Orders o
    WHERE o.order_status <> 'Cancelled'
)
SELECT
    c.customer_id,
    c.name,
    r.order_id AS second_order_id,
    r.order_date AS second_order_date
FROM Customers c
JOIN ranked_orders r
    ON c.customer_id = r.customer_id
WHERE r.rn = 2
ORDER BY second_order_date;

-- Q45. Repeat-customer percentage
WITH customer_orders AS (
    SELECT
        customer_id,
        COUNT(*) AS total_orders
    FROM Orders
    WHERE order_status <> 'Cancelled'
    GROUP BY customer_id
)
SELECT
    ROUND(
        100 * SUM(CASE WHEN total_orders >= 2 THEN 1 ELSE 0 END)
        / COUNT(*),
        2
    ) AS repeat_customer_percentage
FROM customer_orders;

-- Q46. Customer rank by spending
SELECT
    customer_id,
    customer_name,
    total_spending,
    RANK() OVER (
        ORDER BY total_spending DESC
    ) AS spending_rank
FROM vw_CustomerPurchaseSummary
ORDER BY spending_rank;

-- Q47. Running revenue by order date
SELECT
    order_id,
    order_date,
    final_amount,
    SUM(final_amount) OVER (
        ORDER BY order_date, order_id
    ) AS running_revenue
FROM Orders
WHERE order_status <> 'Cancelled'
ORDER BY order_date, order_id;

-- Q48. Category ranking by revenue
SELECT
    category_name,
    revenue,
    DENSE_RANK() OVER (
        ORDER BY revenue DESC
    ) AS category_rank
FROM vw_CategoryRevenue
ORDER BY category_rank;

-- Q49. Customers with no order in the latest 60 days of the dataset
WITH max_order_date AS (
    SELECT MAX(order_date) AS max_date
    FROM Orders
    WHERE order_status <> 'Cancelled'
)
SELECT
    c.customer_id,
    c.name,
    MAX(o.order_date) AS last_order_date
FROM Customers c
LEFT JOIN Orders o
    ON c.customer_id = o.customer_id
   AND o.order_status <> 'Cancelled'
GROUP BY c.customer_id, c.name
HAVING
    MAX(o.order_date) IS NULL
    OR MAX(o.order_date) < (
        SELECT DATE_SUB(max_date, INTERVAL 60 DAY)
        FROM max_order_date
    )
ORDER BY last_order_date;

-- Q50. Customers whose latest order value is above their own average
WITH customer_order_stats AS (
    SELECT
        o.customer_id,
        o.order_id,
        o.order_date,
        o.final_amount,
        AVG(o.final_amount) OVER (
            PARTITION BY o.customer_id
        ) AS customer_avg_order_value,
        ROW_NUMBER() OVER (
            PARTITION BY o.customer_id
            ORDER BY o.order_date DESC, o.order_id DESC
        ) AS rn
    FROM Orders o
    WHERE o.order_status <> 'Cancelled'
)
SELECT
    c.customer_id,
    c.name,
    s.order_id AS latest_order_id,
    s.final_amount AS latest_order_value,
    ROUND(s.customer_avg_order_value, 2) AS customer_average_order_value
FROM customer_order_stats s
JOIN Customers c
    ON c.customer_id = s.customer_id
WHERE s.rn = 1
  AND s.final_amount > s.customer_avg_order_value
ORDER BY s.final_amount DESC;

-- Q51. Products contributing at least 10% of total product revenue
SELECT
    product_id,
    product_name,
    revenue,
    ROUND(
        100 * revenue /
        NULLIF(
            (SELECT SUM(revenue)
             FROM vw_ProductSalesSummary),
            0
        ),
        2
    ) AS revenue_percentage
FROM vw_ProductSalesSummary
WHERE revenue >= 0.10 * (
    SELECT SUM(revenue)
    FROM vw_ProductSalesSummary
)
ORDER BY revenue DESC;

-- Q52. Employee revenue contribution
WITH employee_revenue AS (
    SELECT
        e.employee_id,
        e.name AS employee_name,
        COALESCE(SUM(
            CASE WHEN o.order_status <> 'Cancelled'
                 THEN o.final_amount ELSE 0 END
        ), 0) AS revenue
    FROM Employees e
    LEFT JOIN Orders o
        ON e.employee_id = o.employee_id
    GROUP BY e.employee_id, e.name
)
SELECT
    employee_id,
    employee_name,
    revenue,
    ROUND(
        100 * revenue /
        NULLIF((SELECT SUM(revenue) FROM employee_revenue), 0),
        2
    ) AS revenue_percentage
FROM employee_revenue
ORDER BY revenue DESC;

-- Q53. Product sales by month
SELECT
    DATE_FORMAT(o.order_date, '%Y-%m') AS sales_month,
    p.product_name,
    SUM(oi.quantity) AS quantity_sold,
    SUM(oi.total_price) AS revenue
FROM Orders o
JOIN OrderItems oi
    ON o.order_id = oi.order_id
JOIN Products p
    ON oi.product_id = p.product_id
WHERE o.order_status <> 'Cancelled'
GROUP BY DATE_FORMAT(o.order_date, '%Y-%m'), p.product_name
ORDER BY sales_month, revenue DESC;

-- Q54. Category performance with average order contribution
SELECT
    c.category_name,
    SUM(oi.total_price) AS revenue,
    COUNT(DISTINCT o.order_id) AS orders_containing_category,
    ROUND(
        SUM(oi.total_price) /
        NULLIF(COUNT(DISTINCT o.order_id), 0),
        2
    ) AS average_category_revenue_per_order
FROM Categories c
JOIN Products p
    ON c.category_id = p.category_id
JOIN OrderItems oi
    ON p.product_id = oi.product_id
JOIN Orders o
    ON oi.order_id = o.order_id
WHERE o.order_status <> 'Cancelled'
GROUP BY c.category_id, c.category_name
ORDER BY revenue DESC;

-- Q55. Order status and payment status combination
SELECT
    o.order_status,
    COALESCE(p.payment_status, 'No Payment') AS payment_status,
    COUNT(*) AS order_count
FROM Orders o
LEFT JOIN Payments p
    ON o.order_id = p.order_id
GROUP BY
    o.order_status,
    COALESCE(p.payment_status, 'No Payment')
ORDER BY order_count DESC;

-- Q56. Verify stored order totals against order-item totals
SELECT
    o.order_id,
    o.total_amount AS stored_total,
    COALESCE(SUM(oi.total_price), 0) AS calculated_total,
    o.final_amount AS stored_final_amount,
    ROUND(
        COALESCE(SUM(oi.total_price), 0) - o.total_amount,
        2
    ) AS total_difference
FROM Orders o
LEFT JOIN OrderItems oi
    ON o.order_id = oi.order_id
GROUP BY
    o.order_id,
    o.total_amount,
    o.final_amount
HAVING
    ROUND(COALESCE(SUM(oi.total_price), 0) - o.total_amount, 2) <> 0
ORDER BY o.order_id;
