-- ============================================================
-- CAFE CUSTOMER ANALYSIS
-- CUSTOMER ANALYSIS
-- ============================================================

USE cafe_customer_analysis;

-- Q1. Total customers
SELECT COUNT(*) AS total_customers
FROM Customers;

-- Q2. Customer order frequency
SELECT
    c.customer_id,
    c.name,
    COUNT(o.order_id) AS total_orders
FROM Customers c
LEFT JOIN Orders o
    ON c.customer_id = o.customer_id
GROUP BY c.customer_id, c.name
ORDER BY total_orders DESC;

-- Q3. Customer lifetime spending
SELECT
    c.customer_id,
    c.name,
    COALESCE(SUM(
        CASE WHEN o.order_status <> 'Cancelled'
             THEN o.final_amount ELSE 0 END
    ), 0) AS lifetime_spending
FROM Customers c
LEFT JOIN Orders o
    ON c.customer_id = o.customer_id
GROUP BY c.customer_id, c.name
ORDER BY lifetime_spending DESC;

-- Q4. Average customer spending
SELECT
    AVG(total_spending) AS average_customer_spending
FROM vw_CustomerPurchaseSummary;

-- Q5. Repeat customers
SELECT
    customer_id,
    customer_name,
    total_orders
FROM vw_CustomerPurchaseSummary
WHERE total_orders >= 2
ORDER BY total_orders DESC;

-- Q6. Customers with no orders
SELECT
    c.customer_id,
    c.name,
    c.city
FROM Customers c
LEFT JOIN Orders o
    ON c.customer_id = o.customer_id
WHERE o.order_id IS NULL;

-- Q7. Inactive customers
SELECT
    customer_id,
    name,
    city,
    join_date
FROM Customers
WHERE is_active = FALSE;

-- Q8. Top 10 customers by spending
SELECT
    customer_id,
    customer_name,
    total_spending
FROM vw_CustomerPurchaseSummary
ORDER BY total_spending DESC
LIMIT 10;

-- Q9. Customer segmentation using CASE
SELECT
    customer_id,
    customer_name,
    total_orders,
    total_spending,
    CASE
        WHEN total_spending = 0 THEN 'No Purchase'
        WHEN total_spending < 500 THEN 'Low Value'
        WHEN total_spending < 1000 THEN 'Medium Value'
        ELSE 'High Value'
    END AS customer_segment
FROM vw_CustomerPurchaseSummary
ORDER BY total_spending DESC;

-- Q10. Customers spending above the average customer spending
WITH customer_spending AS (
    SELECT customer_id, customer_name, total_spending
    FROM vw_CustomerPurchaseSummary
)
SELECT *
FROM customer_spending
WHERE total_spending > (
    SELECT AVG(total_spending)
    FROM customer_spending
)
ORDER BY total_spending DESC;

-- Q11. Customers who purchased from at least 3 different categories
SELECT
    c.customer_id,
    c.name,
    COUNT(DISTINCT p.category_id) AS categories_purchased
FROM Customers c
JOIN Orders o
    ON c.customer_id = o.customer_id
JOIN OrderItems oi
    ON o.order_id = oi.order_id
JOIN Products p
    ON oi.product_id = p.product_id
WHERE o.order_status <> 'Cancelled'
GROUP BY c.customer_id, c.name
HAVING COUNT(DISTINCT p.category_id) >= 3
ORDER BY categories_purchased DESC;

-- Q12. Most recent order for every customer
WITH ranked_orders AS (
    SELECT
        o.customer_id,
        o.order_id,
        o.order_date,
        o.final_amount,
        ROW_NUMBER() OVER (
            PARTITION BY o.customer_id
            ORDER BY o.order_date DESC
        ) AS rn
    FROM Orders o
    WHERE o.order_status <> 'Cancelled'
)
SELECT
    c.customer_id,
    c.name,
    r.order_id,
    r.order_date,
    r.final_amount
FROM Customers c
LEFT JOIN ranked_orders r
    ON c.customer_id = r.customer_id
   AND r.rn = 1
ORDER BY r.order_date DESC;
